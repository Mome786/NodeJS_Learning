const express = require("express");
const greetings = require("./routes/greetings")
const users = require("./routes/users")
app = express()
PORT = 3000

app.use(express.json());
app.use("/", greetings)
app.use("/user", users)


app.listen(PORT, (req,res) => {
    console.log("Server Running")
})