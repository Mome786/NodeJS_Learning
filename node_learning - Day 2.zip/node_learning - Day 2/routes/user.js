user =[
    {   
        "id" : 1,
        "name" : "GM",
        "age" : 24,
        "phone": "12345678"
    }
]

module.exports = user