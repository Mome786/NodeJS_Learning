const express = require("express");
const req = require("express/lib/request");
const user = require("./user")
const { json } = require("express/lib/response");
const { request } = require("express");
const router = express.Router()



router.get("/:nam/:age/:phone", (req,res) => {
    age = parseInt(req.params.age);
    nam = req.params.nam,
    phone = req.params.phone,
    obj = {
        "nam" : nam,
        "age" : age,
        "phone": phone,
    }
    console.log(JSON.stringify(obj))
})

router.get("/", (req,res)=> {
    res.json(user)
})

router.post("/", (req,res) => {
    console.log(req.body)
    let user1 = {
        name : req.body.name,
        age : req.body.age,
        phone : req.body.phone
    }
    user.push(user1)
    res.json(user1)
})

router.put("/:id", (req,res)=>{
    let id = req.params.id
    let name = req.body.name
    let age = req.body.age
    let phone = req.body.phone
    const index = user.findIndex((person)=>{
        return (person.id = Number.parseInt(id))
    })
    console.log(index)
    let usr = user[index]
    usr.name = name
    usr.age = age
    usr.phone = phone
    res.json(usr)
    console.log(usr)

})

router.delete("/:id", (req,res)=>{
    let id = req.params.id
    const index = user.findIndex((person)=>{
        return (person.id = Number.parseInt(id))
    })
    let usr = user[index]
    user.splice(index,1)
    res.json(usr)
    console.log(usr)

})



module.exports = router