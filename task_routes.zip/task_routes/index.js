const express = require("express");
app = express()
PORT = 3000

//making endpoints here
app.get("/Morning", (req,res) => {
    res.send("Good Morning")
})

app.get("/Afternoon", (req,res) => {
    res.send("Good Afternoon")
})
app.get("/Evening", (req,res) => {
    res.send("Good Evening")
})
app.get("/Night", (req,res) => {
    res.send("Good Night")
})


// getting parameters from path(url)
app.get("/add/:n1/:n2", (req,res) => {
    n1 = req.params.n1
    n2 = req.params.n2
    n1 = parseInt(n1)
    n2 = parseInt(n2)
    sum = n1 + n2
    sum = sum.toString();
    res.send(sum);
    } )
app.get("/sub/:n1/:n2", (req,res) => {
    n1 = req.params.n1
    n2 = req.params.n2
    n1 = parseInt(n1)
    n2 = parseInt(n2)
    sub = n1 - n2
    sub = sub.toString();
    res.send(sub);
    } )
app.get("/mul/:n1/:n2", (req,res) => {
    n1 = req.params.n1
    n2 = req.params.n2
    n1 = parseInt(n1)
    n2 = parseInt(n2)
    mul = n1 * n2
    mul = mul.toString();
    res.send(mul);
    } )   
app.get("/div/:n1/:n2", (req,res) => {
    n1 = req.params.n1
    n2 = req.params.n2
    n1 = parseInt(n1)
    n2 = parseInt(n2)
    div = n1 / n2
    div = div.toString();
    res.send(div);
    } )    

app.listen(PORT, (req,res) => {
    console.log("Server Running")
})